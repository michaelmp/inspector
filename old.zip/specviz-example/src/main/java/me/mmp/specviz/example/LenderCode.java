package me.mmp.specviz.example;

import me.mmp.specviz.Node;

@Node(value = "Lender Code")
public class LenderCode {

}
