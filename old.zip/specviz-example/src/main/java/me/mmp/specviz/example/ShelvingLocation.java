package me.mmp.specviz.example;

import me.mmp.specviz.Node;

@Node(value = "Shelving Location")
public class ShelvingLocation {

}
