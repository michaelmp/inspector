package me.mmp.specviz.example;

import me.mmp.specviz.Edge;
import me.mmp.specviz.Node;
import me.mmp.specviz.vocab.dc.Agent;
import me.mmp.specviz.vocab.vcard.Key;

@Node(value = "User", typeof = Agent.class)
public class User {

    @Edge(value = "has a public key", properties = Key.class)
    private String publicKey;

}
