package me.mmp.specviz.example;

import java.util.List;
import me.mmp.specviz.Edge;
import me.mmp.specviz.Node;
import me.mmp.specviz.vocab.dc.References;
import me.mmp.specviz.vocab.dc.Search;

@Node(value = "AQ Result", typeof = Search.class)
public class AQResult {

    @Edge(value = "suggests an item", properties = References.class)
    private List<Item> holdings;
}
