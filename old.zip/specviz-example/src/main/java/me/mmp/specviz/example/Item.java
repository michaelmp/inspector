package me.mmp.specviz.example;

import me.mmp.specviz.Edge;
import me.mmp.specviz.Node;

@Node(value = "Item")
public class Item {

    @Edge
    private LenderCode lender;
    @Edge
    private ShelvingLocation location;
}
