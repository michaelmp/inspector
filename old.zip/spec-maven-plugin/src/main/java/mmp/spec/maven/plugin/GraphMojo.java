package mmp.spec.maven.plugin;

import java.util.Arrays;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;

@Mojo(name = "graph")
public class GraphMojo extends AbstractMojo {

    @Parameter
    String[] packages;

    @Override
    public void execute() throws MojoExecutionException {
        try {
            Arrays.asList(ClassLoader.getSystemClassLoader().loadClass("").getAnnotations()).forEach((a) -> {
                
            });
        } catch (ClassNotFoundException ex) {
            throw new MojoExecutionException("", ex);
        }
    }
}
