package me.mmp.specviz.vocab.foaf;

import me.mmp.specviz.Vocab;

public interface FriendOfAFriend extends Vocab {
    
}
