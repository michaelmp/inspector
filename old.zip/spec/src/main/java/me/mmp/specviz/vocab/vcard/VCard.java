package me.mmp.specviz.vocab.vcard;

import java.net.MalformedURLException;
import java.net.URL;
import me.mmp.specviz.Vocab;

public interface VCard extends Vocab {

    @Override
    default URL uri() throws MalformedURLException {
        return new URL("http://www.w3.org/2006/vcard/ns#");
    }

    @Override
    default String prefix() {
        return "dc";
    }

}
