package me.mmp.specviz;

import java.net.URL;

public interface Vocab {

    URL uri() throws java.net.MalformedURLException;

    String prefix();

}
