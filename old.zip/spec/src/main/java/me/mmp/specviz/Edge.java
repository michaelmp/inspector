package me.mmp.specviz;

public @interface Edge {

    String value() default "";

    Class target() default Void.class;

    String[] tags() default {};

    Class<? extends Term>[] typeof() default {};

    Class<? extends Term>[] properties() default {};

}
