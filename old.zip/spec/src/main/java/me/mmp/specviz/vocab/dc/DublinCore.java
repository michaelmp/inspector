package me.mmp.specviz.vocab.dc;

import java.net.MalformedURLException;
import java.net.URL;
import me.mmp.specviz.Term;
import me.mmp.specviz.Vocab;

public interface DublinCore extends Vocab {

    @Override
    default URL uri() throws MalformedURLException {
        return new URL("http://purl.org/dc/terms");
    }

    @Override
    default String prefix() {
        return "dc";
    }
    
    public static final class dc {
        public static final Class<? extends Term> Agent = Agent.class;
    }
}
