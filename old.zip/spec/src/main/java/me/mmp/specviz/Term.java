package me.mmp.specviz;

import java.net.URL;

public interface Term {

    URL uri() throws java.net.MalformedURLException;

    Class<? extends Vocab> vocab();

}
