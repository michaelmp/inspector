package me.mmp.specviz.vocab.foaf;

import java.net.MalformedURLException;
import java.net.URL;
import me.mmp.specviz.Term;
import me.mmp.specviz.Vocab;

public class Document implements Term {

    @Override
    public URL uri() throws MalformedURLException {
        return new URL("http://xmlns.com/foaf/0.1/");
    }

    @Override
    public Class<? extends Vocab> vocab() {
        return FriendOfAFriend.class;
    }

}
