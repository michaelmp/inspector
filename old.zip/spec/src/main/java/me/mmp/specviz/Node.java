package me.mmp.specviz;

public @interface Node {

    String value() default "";

    String[] tags() default {};

    Class<? extends Term>[] typeof() default {};

    Class<? extends Term>[] properties() default {};

}
