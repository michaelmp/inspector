package me.mmp.specviz.vocab.dc;

import java.net.MalformedURLException;
import java.net.URL;
import me.mmp.specviz.Term;
import me.mmp.specviz.Vocab;

public class Agent implements Term {

    @Override
    public URL uri() throws MalformedURLException {
        return new URL("http://purl.org/dc/terms/Agent");
    }

    @Override
    public Class<? extends Vocab> vocab() {
        return DublinCore.class;
    }

}
